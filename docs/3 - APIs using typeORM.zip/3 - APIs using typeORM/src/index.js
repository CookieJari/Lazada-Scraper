// src/index.js
require('reflect-metadata');
const { createConnection } = require('typeorm');
const express = require('express');
const Product = require('./Product');


//const express = require('express');
const bodyParser = require('body-parser');

const app = express();

// Middleware configuration
app.use(bodyParser.json());

//const app = express();
const port = 3000;

createConnection({
  type: 'mysql',
  host: '172.23.0.2',
  port: 3306,
  username: 'root',
  password: 'mysecretpassword',
  database: 'lazprice_dev',
  entities: [Product],
  synchronize: true,
})
  .then(async (connection)  => {
    console.log('Database connection established');

    const productRepository = connection.getRepository(Product);

// GetProductItem-service / all
app.get('/products', async (req, res) => {
  try {
    const latestProducts = await productRepository
      .createQueryBuilder('product')
      .where((qb) => {
        const subQuery = qb
          .subQuery()
          .select('MAX(subProduct.id)')
          .from('products', 'subProduct')
          .where('subProduct.product_url = product.product_url')
          .getQuery();
        return 'product.id IN ' + subQuery;
      })
      .getMany();

    res.json(latestProducts);
  } catch (error) {
    console.error('Error retrieving latest products:', error);
    res.status(500).json({ error: 'An error occurred while retrieving the latest products.' });
  }
});




// insert by post request with body
// expect to pass  product_name, product_url, product_price, product_image
app.post('/products', async (req, res) => {
  console.log(req.body);
  const { product_name, product_url, product_price, product_image } = req.body;

  try {
    // Retrieve the previous price
    const previousPriceQuery = productRepository.createQueryBuilder('product')
      .select('product.product_price')
      .where('product.product_url = :productUrl', { productUrl: product_url })
      .orderBy('product.id', 'DESC')
      .limit(1);

      const previousPriceResult = await previousPriceQuery.getRawOne();
      const previousPrice = previousPriceResult ? previousPriceResult.product_product_price : null;

    // Create and save the new product
    const product = productRepository.create({
      product_name,
      product_url,
      product_price,
      product_image,
      previous_price: previousPrice, // Set the previous_price value
    });

    const savedProduct = await productRepository.save(product);
    res.json(savedProduct);
  } catch (error) {
    console.error('Error saving product:', error);
    res.status(500).json({ error: 'Failed to insert product into the database', databaseError: error.message });
  }
});


// GetProductPrice-history / by product_url
app.post('/products/historical_prices', async (req, res) => {
  const { product_url } = req.body;

  try {
    const product = await productRepository.findOne({
      where: {
        product_url: product_url,
      },
      select: ['product_name', 'product_price', 'date_inserted'],
      order: {
        date_inserted: 'DESC',
      },
    });

    if (!product) {
      return res.status(404).json({ error: 'No product found with the specified URL' });
    }

    const historicalPrices = await productRepository.find({
      where: {
        product_url: product_url,
      },
      select: ['product_name', 'product_price', 'product_image', 'date_inserted'],
      order: {
        date_inserted: 'ASC',
      },
    });

    res.json(historicalPrices);
  } catch (error) {
    console.error('Error retrieving product history:', error);
    res.status(500).json({ error: 'An error occurred while retrieving the product history.' });
  }
});

app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
  })
  .catch((error) => {
    console.error('Error connecting to the database:', error);
  });
